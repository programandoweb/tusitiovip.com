<html>
  <head></head>
  <body>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.3/jquery.min.js"></script>
    <link href="instalink-2.1.10.min.css" rel="stylesheet">
    <script src="instalink-2.1.10.min.js"></script>

    <div data-il
     data-il-api="/instalink/api/"
     data-il-username="elfsight"
     data-il-hashtag=""
     data-il-lang="en"
     data-il-show-heading="true"
     data-il-scroll="true"
     data-il-width="270px"
     data-il-height="350px"
     data-il-image-size="medium"
     data-il-bg-color="#285989"
     data-il-content-bg-color="#F8F8F8"
     data-il-font-color="#FFFFFF"
     data-il-ban="">
</div>
  </body>

</html>
