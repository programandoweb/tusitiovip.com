<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
  DESARROLLADO POR JORGE MENDEZ
  programandoweb.net
  info@programandoweb.net
  Colombia - Venezuela - Chile
**/

echo "\nERROR: ",
	$heading,
	"\n\n",
	$message,
	"\n\n";