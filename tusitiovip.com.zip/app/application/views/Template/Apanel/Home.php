<?php
$colores	=	array(	"Agua_Amarilla",
						"Blue",
						"Yellow",
						"Green",
						"Purple",
						"Orange",
						"a",
						"b",
						"c",
						"d");
?>
<div class="container">
	<div class="row justify-content-md-center">
    <div class="col-md-12">

    </div>
	</div>
</div>
