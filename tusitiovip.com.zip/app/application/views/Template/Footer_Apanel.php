<?php if(!isset($hide)){?>
<footer class="bg-dark apanel_footer">
  <div class="container text-center">
    <a href="https://programandoweb.net"> <h5 class="text-white">Desarrollado por ProgramandoWeb.net</h5></a>
  </div>
</footer>
<?php }?>
<?php echo template_footer();?>
