<div class="container text-center welcome">
	<img src="<?php echo DOMINIO?>images/Logo-Webcamplus-md.png" class="rounded mx-auto d-block" alt="..." />
	<h1 class="font-weight-700 text-uppercase">Error 500 - Seleccione Sucursal</h1>
    <h2>Contactanos </h2>
    <h5><?php echo SMTP_USER;?></h5>
</div>