<section class="mb-1">
  <div class="container-fluid">
    <div class="row p-5 text-center">
			<div class="col">
				<div class="p-5" data-parallax="true">
					<div class="container text-center p-5">
						<img src="<?php echo IMG?>logo-xs.png" class="rounded mx-auto d-block" alt="..." />
						<h1 class="font-weight-700 text-uppercase mt-5">Error 500 - Rol de Usuario sin Provilegios</h1>
					    <h2>Contacta al administrador del sistema</h2>
					    <h5><?php echo SMTP_USER;?></h5>
					</div>
				</div>
			</div>
    </div>
  </div>
</section>
