<div class="page-header header-filter clear-filter purple-filter" data-parallax="true" style="background-image: url('<?php echo IMG;?>uploads/home/studient.jpg');">
	<div class="container">
		<div class="row justify-content-md-center">
			<div class="col-4 pl-5 pr-5 section">
				<div class="bg-black"></div>
				<h3 class="text-center">who you are?</h3>
				<div id="medios">
					<div class="form-group row pt-0 mt-0 justify-content-center ">
						<a href="<?php echo base_url("Register_User")?>" class="btn btn-primary btn-sm col-sm-5">Private User</a>
						<a href="<?php echo base_url("Register_University")?>" class="btn btn-purple btn-sm col-sm-4">College</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
