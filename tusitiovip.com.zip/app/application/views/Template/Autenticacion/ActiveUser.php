<div class="container margin-top-100">
	<div class="row justify-content-md-center">
    	<div class="col">
        	<img src="<?php echo DOMINIO?>images/Logo-Webcamplus-md.png" class="rounded mx-auto d-block" alt="..." />
            <div class="row">
            	<div class="text-center col-md-12">
	            	<h1 class="font-weight-700 text-uppercase">Sistema de Activación de Usuarios PGRW</h1>
                </div>
            	<div class="col-md-6 offset-md-3">
					
	                <div class="container text-center">
                        <h2>Desarrollo Basado en Codeigniter</h2>
                        <h3>Por ProgramandoWeb</h3>
                        <h4>Desarrollo y Creatividad</h4>
                        <h5>Info@Programandoweb.net</h5>
                        <a href="<?php echo base_url("autenticacion")?>">Sistema de Autenticación</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
