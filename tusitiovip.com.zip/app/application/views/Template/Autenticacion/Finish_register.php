<div class="page-header header-filter clear-filter purple-filter" data-parallax="true" style="background-image: url('<?php echo IMG;?>uploads/home/studient.jpg');">
	<div class="container">
		<div class="row justify-content-md-center">
			<div class="col-6 pl-5 pr-5 section">
				<div class="bg-black"></div>
				<h3 class="text-center text-white">University Registry</h3>
				<div class="text-center text-white">Please confirm your subscription, check the email tray with the steps to follow.</div>
				<div class="text-center text-white mt-3">
					<a href="<?php echo base_url();?>" class="btn btn-primary btn-sm">Go to the main page</a>
				</div>
			</div>
		</div>
	</div>
</div>
