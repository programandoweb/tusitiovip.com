<nav class="navbar navbar-expand-md bg-light text-black">
  <div class="container">
    <button class="navbar-toggler collapsed text-secondary" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-ellipsis-v"></i>
    </button>
    <div class="navbar-collapse collapse" id="navbarsExampleDefault" style="">
      <ul class="navbar-nav mr-auto">
				<li class="nav-item active">
          <a class="nav-link" href="<?php echo base_url()?>">Home</a>
        </li>
        <!--li class="nav-item active">
          <a class="nav-link" href="<?php echo base_url("Apartamentos")?>">Apartamentos</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url("Casas")?>">Casas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url("Locales")?>">Locales</a>
        </li>
				<li class="nav-item">
          <a class="nav-link" href="<?php echo base_url("Fincas")?>">Fincas</a>
        </li-->
      </ul>
			<ul class="navbar-nav ml-auto">
        <li class="nav-item active">
					Promociones
				</li>
			</ul>
    </div>
  </div>
</nav>
