<div id="flash">
    <div class="container">
        <div class="row text-center"> 
            <div class="col-md-6 offset-md-3">
                <?php session_flash();?>
            </div>
        </div>
    </div>
</div>